var express = require("express");
var app = express();
var bodyParser = require("body-parser");

app.use(bodyParser.urlencoded({extended:true}));
app.set("view engine","ejs");
app.use(express.static("public"));

var friends=["Lily","Susan","Jing","Nancy"];

app.get("/", function(req,res){
	res.send("home page");
})
app.post("/addfriends",function(req,res){
	var newfriend = req.body.newfriend;
	friends.push(newfriend);
	res.redirect("/friends");
})
app.get("/friends",function(req,res){

	res.render("friends",{friends:friends});
})
app.listen(3000,function(){
	console.log("Server Started!!")
})
