# AfterSchool-Projects
- Here you will find some projects that I did after school
- [Desktop Calculator App](/DesktopCalculator): Used C# with WPF(Windows Presentation Form) Framework created a desktop App, Inside the code used two cool features:1, how to rotating an image; 2. how to add JavaScript code inside C# code with Guid ID.
- [DeseralizeJSON WITH .NET CORE](/Post_Get_Info_InDesignWay):Using .NET Core, deserializing Json files and  pulling information out of Json Files
- [Score Keeper](/Score%20Keeper): Understanding DOM and connecting HTML, CSS and JavaScript together build this project to allow user to keep the score or reset their score, even they can change the limit game times.
- [Simple JavaScript TODOLIST](/Simple-toDoList-JS) Using JavaScript code.You can practice "ADD","LIST","DELETE","QUIT" into the toDoList.
- [Fun RGB color Game](/RGB%20Guessing%20Game) This Project allows player to match RGB color with the display one, and player got to choose "Easy Mode" & "Hard Mode". 
- [The sum of the first 100 prime numbers](/The%20sum%20of%20the%20first%20100%20prime%20numbers) Explaining what is Prime Numbers and how to sum up.
- [To-Do List](/toDoList) 
