﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.EntityFrameworkCore;

//namespace Post_Get_Info_InDesignWay.Data
//{
//    public class ResultContext:DbContext
//    {
//        public ResultContext(DbContextOptions<ResultContext> options) : base(options)
//        {

//        }
//        public DbSet<ResultContext> Result { get; set; }
//    }
//}
